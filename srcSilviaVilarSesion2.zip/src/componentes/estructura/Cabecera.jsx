import React, { Fragment } from "react";
import "./Cabecera.css";

const Cabecera = () => {
    return (
        <Fragment>
            <header className="cabecera">
                <h1 className="cabecera_titulo">Mi biblioteca</h1>
            </header>
        </Fragment>
    );
};
export default Cabecera;